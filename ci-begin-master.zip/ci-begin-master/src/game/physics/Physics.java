package game.physics;

public interface Physics {
      BoxCollider getBoxCollider();
}
